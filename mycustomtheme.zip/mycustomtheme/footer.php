<footer>
    <p>&copy; <?php echo date('Y'); ?> My Custom Theme. All rights reserved.</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
