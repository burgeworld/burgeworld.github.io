<?php get_header(); ?>

<div class="content">
    <h2>Welcome to My Custom Theme</h2>
</div>

<?php get_footer(); ?>
